<?php

require "config/constants.php";

$servername = HOST;
$username = USER;
$password = PASSWORD;
$db = DATABASE_NAME;

// Creer la connexion
$con = mysqli_connect($servername, $username, $password,$db);

// Vérifier la connexion
if (!$con) {
    die("La connexion a échoué: " . mysqli_connect_error());
}


?>