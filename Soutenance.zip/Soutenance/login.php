<?php
include "db.php";

session_start();

#Le script de connexion commence ici
#Si les informations d'identification fournies par l'utilisateur correspondent avec succès aux données disponibles dans la base de données, nous ferons écho à la chaîne login_success
#La chaîne login_success reviendra à la fonction anonyme appelée $("#login").click()
if(isset($_POST["email"]) && isset($_POST["password"])){
	$email = mysqli_real_escape_string($con,$_POST["email"]);
	$password = md5($_POST["password"]);
	$sql = "SELECT * FROM user_info WHERE email = '$email' AND password = '$password'";
	$run_query = mysqli_query($con,$sql);
	$count = mysqli_num_rows($run_query);
	//si l'enregistrement de l'utilisateur est disponible dans la base de données alors $count sera égal à 1
	if($count == 1){
		$row = mysqli_fetch_array($run_query);
		$_SESSION["uid"] = $row["user_id"];
		$_SESSION["name"] = $row["first_name"];
		$ip_add = getenv("REMOTE_ADDR");
		//nous avons créé un cookie dans la page login_form.php donc si ce cookie est disponible, cela signifie que l'utilisateur n'est pas connecté
			if (isset($_COOKIE["product_list"])) {
				$p_list = stripcslashes($_COOKIE["product_list"]);
				//ici, nous décodons le cookie de liste de produits json stocké en un tableau normal
				$product_list = json_decode($p_list,true);
				for ($i=0; $i < count($product_list); $i++) { 
					//Après avoir obtenu l'identifiant de l'utilisateur de la base de données, nous vérifions ici l'élément du panier de l'utilisateur s'il y a déjà un produit répertorié ou non
					$verify_cart = "SELECT id FROM cart WHERE user_id = $_SESSION[uid] AND p_id = ".$product_list[$i];
					$result  = mysqli_query($con,$verify_cart);
					if(mysqli_num_rows($result) < 1){
						//si l'utilisateur ajoute un produit pour la première fois dans le panier, nous mettrons à jour user_id dans la table de base de données avec un identifiant valide
						$update_cart = "UPDATE cart SET user_id = '$_SESSION[uid]' WHERE ip_add = '$ip_add' AND user_id = -1";
						mysqli_query($con,$update_cart);
					}else{
						//si déjà ce produit est disponible dans la table de la base de données, nous supprimerons cet enregistrement
						$delete_existing_product = "DELETE FROM cart WHERE user_id = -1 AND ip_add = '$ip_add' AND p_id = ".$product_list[$i];
						mysqli_query($con,$delete_existing_product);
					}
				}
				//ici nous détruisons le cookie de l'utilisateur
				setcookie("product_list","",strtotime("-1 day"),"/");
				//si l'utilisateur se connecte après la page du panier, nous enverrons cart_login
				echo "cart_login";
				exit();
				
			}
			//Si l'utilisateur se connecte à partir de la page nous enverrons connexion avec succès
			echo "Connexion avec succès";
			exit();
		}else{
			echo "<span style='color:red;'>Veuillez vous inscrire avant de vous connecter..!</span>";
			exit();
		}
	
}

?>