<?php

#ceci est la page du formulaire de connexion, si l'utilisateur est déjà connecté, nous n'autoriserons pas l'utilisateur à accéder à cette page en exécutant isset($_SESSION["uid"])
#si la déclaration ci-dessous renvoie true, nous enverrons l'utilisateur à sa page profile.php
if (isset($_SESSION["uid"])) {
	header("location:profile.php");
}

//dans la page action.php si l'utilisateur clique sur le bouton "prêt à payer", nous transmettrons les données dans un formulaire à partir de la page action.php
if (isset($_POST["login_user_with_product"])) {
	//il s'agit d'un tableau de liste de produits
	$product_list = $_POST["product_id"];
	//ici, nous convertissons le tableau au format json car le tableau ne peut pas être stocké dans un cookie
	$json_e = json_encode($product_list);
	//ici nous créons un cookie et le nom du cookie est product_list
	setcookie("product_list",$json_e,strtotime("+1 day"),"/","","",TRUE);

}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="UTF-8">
		<title>Ecommerce</title>
		<link rel="stylesheet" href="css/bootstrap.min.css"/>
		<script src="js/jquery2.js"></script>
		<script src="js/bootstrap.min.js"></script>
		<script src="main.js"></script>
		<link rel="stylesheet" type="text/css" href="style.css">
	</head>
<body>
<div class="wait overlay">
	<div class="loader"></div>
</div>
	<div class="navbar navbar-inverse navbar-fixed-top">
		<div class="container-fluid">	
			<div class="navbar-header">
				<a href="#" class="navbar-brand">Ecommerce</a>
			</div>
			<ul class="nav navbar-nav">
				<li><a href="index.php"><span class="glyphicon glyphicon-home"></span>Accueil</a></li>
				<li><a href="index.php"><span class="glyphicon glyphicon-modal-window"></span>Produit</a></li>
			</ul>
		</div>
	</div>
	<p><br/></p>
	<p><br/></p>
	<p><br/></p>
	<div class="container-fluid">
		<div class="row">
			<div class="col-md-2"></div>
			<div class="col-md-8" id="signup_msg">
				<!--Alerte depuis le formulaire d'inscription-->
			</div>
			<div class="col-md-2"></div>
		</div>
		<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4">
				<div class="panel panel-primary">
					<div class="panel-heading">Formulaire de connexion du client</div>
					<div class="panel-body">
						<!--Formulaire de connexion utilisateur-->
						<form onsubmit="return false" id="login">
							<label for="email">Email</label>
							<input type="email" class="form-control" name="email" id="email" required/>
							<label for="email">Password</label>
							<input type="password" class="form-control" name="password" id="password" required/>
							<p><br/></p>
							<a href="#" style="color:#333; list-style:none;">Mot de passe oublié</a><input type="submit" class="btn btn-success" style="float:right;" Value="Login">
							<!--Si l'utilisateur n'a pas de compte, il/elle cliquera sur le bouton Créer un compte-->
							<div><a href="customer_registration.php?register=1">Creer un nouveau compte?</a></div>						
						</form>
				</div>
				<div class="panel-footer"><div id="e_msg"></div></div>
			</div>
		</div>
		<div class="col-md-4"></div>
	</div>
</body>
</html>






















